#!/bin/bash

cd ./weights
wget -O yolo.pth https://www.dropbox.com/s/nt5mddry9kuhyte/yolo.pth?dl=0
wget -O best.pth https://www.dropbox.com/s/a9nxmt6fcmgnkaj/best.pth?dl=0